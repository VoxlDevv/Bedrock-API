class FailedClass {
  InvalidCommand(player, commandName) {
    return player.sendMessage({ 
      rawtext: [ 
        { 
          text: "§c" 
        }, 
        { 
          translate: "commands.generic.unknown",
          with: [`§f${commandName}§c`], 
        }, 
      ],
    });
  }
}

export { FailedClass }
