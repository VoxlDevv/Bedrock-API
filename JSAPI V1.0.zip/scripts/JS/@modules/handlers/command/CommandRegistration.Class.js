import * as Validator from "../../utils/Validation.Function.js";

class CommandRegistration{
  constructor() {
    this.name = "";
    this.description = "No Description";
    this.private = false;
    this.category = "";
    this.requireTags = [];
    this.aliases = [];
    this.usage = [];
    this.example = [];
  }
  
  setName(string) {
    this.name = string;
    return this;
  }
  
  setDescription(string) {
    this.description = string;
    return this;
  }
  
  setPrivate(boolean) {
    this.private = boolean;
    return this;
  }
  
  setCategory(string) {
    this.category = string;
    return this;
  }
  
  setRequireTags(array) {
    this.requireTags = array;
    return this;
  }
  
  setAliases(array) {
    this.aliases = array;
    return this;
  }
  
  setUsage(array) {
    this.usage = array;
    return this;
  }
  
  setExample(array) {
    this.example = array;
    return this;
  }
  
  extractJSON() {
    return {
      name: this.name,
      description: this.description,
      private: this.private,
      category: this.category,
      requireTags: this.requireTags,
      aliases: this.aliases,
      usage: this.usage,
      example: this.example,
    }
  }
}

export { CommandRegistration }