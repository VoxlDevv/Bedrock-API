import { world, Player } from "@minecraft/server";
import { ChatClass } from "../message/Chat.Class.js";

class PlayerClass {
  /**
   * Get player scoreboard score 
   * @param {string|Player} player - Player target (player name or object)
   * @param {string} objective - Scoreboard objective name
   * @returns {number}
   * @example 
   * getScore(playerObj, "money");
   * getScore("JustSky001", "money");
   */
  getScore(player, objective) {
    return (world.scoreboard.getObjective(objective) ?? world.scoreboard.addObjective(objective, objective))
      .getScore(typeof player === `string` ? world.scoreboard.getParticipants().find((sb) => sb.displayName == player) : player.scoreboardIdentity)
  }
  
  /**
   * Get player xp level 
   * @param {Player} player - Player object
   * @returns {number}
   * @example getXpLevel(playerObj);
   */
  getXpLevel(player) {
    return player.level;
  }
  
  /**
   * Get player specific tag 
   * @param {Player} player - Player object
   * @returns {boolean|string}
   * @example getSpecificTag(playerObj, "tag:");
   */
  getSpecificTag(player, startswith) {
    const check = this.getTags(player)?.find((tag) => tag.startsWith(startswith));
    return check ? check : false;
  }
  
  /**
   * Get player all tag 
   * @param {Player} player - Player object
   * @returns {Array<string>}
   * @example getTags(playerObj);
   */
  getTags(player) {
    return player.getTags();
  }
  
  /**
   * Check player if had tag
   * @param {Player} player - Player object
   * @param {string} tag - Tag
   * @returns {boolean}
   * @example hasTag(playerObj, "tag");
   */
  hasTag(player, tag) {
    return player.hasTag(tag);
  }
  
  /**
   * Check player if online 
   * @param {Player} player - Player object
   * @returns {boolean}
   * @example isOnline(playerObj);
   */
  isOnline(player) {
    return this.getAllPlayers().find((name) => name === player) !== undefined;
  }
  
  /**
   * Get all player in the world
   * @param {boolean} asNumber - Types
   * @returns {Array<string>|number}
   * @example getAllPlayers(true);
   */
  getAllPlayers(asNumber = false) {
    return asNumber ? 
      world.getAllPlayers().length : world.getAllPlayers();
  }
}

export { PlayerClass }