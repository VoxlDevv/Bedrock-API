class Collection extends Map {
  constructor() {
    super();
  }
  
  find(fn) {
    for (const [key, value] of this) {
      if (fn(value, key, this)) return value;
    }
  }
}

export { Collection }
