import { system } from "@minecraft/server";

/**
 * Repeatedly executing a function 
 * @param {function} callback
 * @param {number} tick
 * @returns {number}
 */
function setTickInterval(callback, tick) {
  const timerId = system.runInterval(callback, tick);
  return timerId;
}

/**
 * Executing a function with delay
 * @param {function} callback
 * @param {number} tick
 * @returns {number}
 */
function setTickTimeout(callback, tick) {
  const timerId = system.runTimeout(callback, tick);
  return timerId;
}

/**
 * Same with setTickInterval but without tick
 * @param {function} callback
 * @returns {number}
 */
function setInfinityLoop(callback) {
	const timerId = system.run(callback, tick);
	return timerId;
}

/**
 * Clear tick
 * @param {number} timerId
 * @example
 * const run = setTickInterval(YourFunction, 20);
 * clearTick(run);
 */
function clearTick(timerId) {
  system.clearRun(timerId);
}

/**
 * Like setTickTimeout but without function
 * @param {number} tick
 * @returns {Promise}
 * @example
 * console.warn("One");
 * sleep(20);
 * console.warn("Two");
 */
async function sleep(tick) {
  try {
  	return new Promise((resolve, reject) => {
  		system.runTimeout(resolve, tick);
  	});
  } catch (err) {
    console.warn(err, err.stack);
  }
}

export { 
  setTickInterval, 
  setTickTimeout, 
  setInfinityLoop, 
  clearTick, 
  sleep 
}