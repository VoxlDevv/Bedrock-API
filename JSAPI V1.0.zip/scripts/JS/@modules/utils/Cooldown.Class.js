class CooldownClass {
  constructor(name) {
    this.cooldowns = new Map();
    this.name = name;
  }

  start(duration) {
    const endTime = Date.now() + (duration * 1000);
    this.cooldowns.set(this.name, endTime);
  }

  isActive() {
    const endTime = this.cooldowns.get(this.name);
    if (!endTime) {
      return false;
    }
    return Date.now() < endTime;
  }

  getTime() {
    const endTime = this.cooldowns.get(this.name);
    if (!endTime) {
      return 0;
    }
    return Math.max(0, endTime - Date.now());
  }
}

export { CooldownClass }