function isString(string) {
  return typeof string === "string";
}

function isNumber(number) {
  return typeof number === "number";
}

function isInteger(integer) {
  return Number.isInteger(integer);
}

function isBoolean(boolean) {
  return typeof boolean === "boolean";
}

function isObject(object) {
  return typeof object === 'object' && !Array.isArray(object) && object !== null;
}

function isArray(array) {
  return Array.isArray(array);
}

export {
  isString,
  isNumber,
  isInteger,
  isBoolean,
  isObject,
  isArray
}
