import * as API from "../../class.chain.js";

const registration = new API.CommandRegistration()
  .setName("example")
  .setDescription("Example command")
  .setAliases(["ex"])
  
API.Command.BuildCommand(registration, (data) => {
  data.DB.used.set("Command", {
    prefix: "0"
  })
})