// Import your command
import "./example/example.js";