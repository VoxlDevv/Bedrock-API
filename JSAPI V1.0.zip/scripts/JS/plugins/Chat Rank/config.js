const RankConfig = {
	defaultRank: "§7[Member] §r{name} §7>> §r{msg}", // Default rank 
}

export { RankConfig }