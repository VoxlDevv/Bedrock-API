const Config = {
	defaultPrefix: "!", // Default custom command prefix
	disableWatchDog: true, // Change to true when your world crashes
	version: "1.0.0",
}

export { Config }